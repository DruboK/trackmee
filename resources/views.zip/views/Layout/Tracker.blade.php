<!DOCTYPE html>
<html>
    <head>
        <title>
            Tracker-@yield('title')
        </title>
    </head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>@yield('title')</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="{{asset('/jQuery/jquery-3.3.1.js')}}"></script>
    <script src="{{asset('/bootstrap/bootstrap-3.3.7-dist/js/bootstrap.min.js')}}"></script>
    <link rel="stylesheet" type="text/css" href="{{asset('/bootstrap/bootstrap-3.3.7-dist/css/bootstrap.min.css')}}"/>
    <link rel="stylesheet" type="text/css" href="{{asset('/css/backend/trackMee.css')}}"/>
    <script src="main.js"></script>
    <script src="{{asset('/fontawesome-free-5.0.8/fontawesome-free-5.0.8/svg-with-js/js/fontawesome-all.js')}}"></script>
    <style>
        body{
            /* background-image: url("{{ asset('/photos/Night-Sky-Wallpaper-in-HD-Resolution-wpc2007362.jpg') }}") ;
             background-repeat: no-repeat;
             background-attachment:fixed;
             color:white;*/
        }
        li{


        }

    </style>
</head>
<body>
<body>

</body>
</html>