@extends('Layout.frontend')

@section('title')
About
@endsection
@section('content')
<div class="col-md-6" style="margin-left: 28%;
    margin-top: 9%;">

							<h2 class="mb-0 text-color-dark" style="color: red">About Us</h2>
							<hr style=" margin-left: 1px;
    width: 136px;
 border-top: 1px solid black;">
							<p style="color: black;">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
							consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
							cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
							proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
							

						</div>
@endsection

