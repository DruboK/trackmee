@extends('Layout.Admin')
@section('title')
Dashboard
@endsection

@section('content')
<center>
    <h1>Welcome Home Admin</h1> 
</center>
@endsection
